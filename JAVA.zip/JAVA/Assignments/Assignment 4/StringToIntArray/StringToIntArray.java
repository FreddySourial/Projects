
import java.util.*;

/* CST8110 - Introduction to Computer Programming
 * Section: 472
 * Semester: 20F
 * Professor: Wail Mardini
 * Student ID: 041013272
 * Student Email: sour0025@algonquinlive.com
 * Assignment 4
 */

public class StringToIntArray {

    private int[] intArray = new int[10];
    //to initialize int Array

    public StringToIntArray(){

        Arrays.fill(intArray, Integer.MIN_VALUE);  
        //use the Arrays fill method to populate intArray

    }

    public int indexOf(int intToFind){   
        //method to find the index of an integer in intArray
        int pos = 0;

        for(int i=0; i<intArray.length; i++){ 
            //loop through intArray
            if(intArray[i]==intToFind){
                //if element equal to intToFind

                pos = i;

                break;

            }else{
                pos = -1; 
                //if above case is invalid it is -1
            }
        }

        return pos;

    }

    public int indexOf(String intToFind){ 
        //when method is a string, overload

        int integer = Integer.parseInt(intToFind); 
        //parse string to integer
        return indexOf(integer); 
        //use previous method on the parsed integer
    }

    public boolean contains(int intToFind){
        return indexOf(intToFind) != -1; 
        //if indexOf is not -1, then in intArray
    }

    public boolean contains(String intToFind){
        return indexOf(intToFind) != -1;
        //if indexOf is not -1, then it is in intArray
    }

    public int get(int index){ 
        //method to get value at an index
        if(index>intArray.length){ 
            //condition if index is out of bounds
            return Integer.MIN_VALUE;
        }else if(index < 0){ 
            // when index is negative
            return Integer.MIN_VALUE;
        }else{ 
            //return element
            return intArray[index];
        }
    }

    public boolean scanStringToIntArray(String s, boolean skipErrors){ 
        // to scan string  
        Scanner scanner = new Scanner(s);  
        //new  scanner  initialized 
        boolean success = false; 
        //making sure it was scanned to intArray

        while(scanner.hasNext()){ 
            //while there is a token in s yet to be read
            if(scanner.hasNextInt()){ 
                //check if there is an integer
                int pos = 0;
                boolean done = false;
                while(!done){
                    if(intArray[intArray.length-1] == Integer.MIN_VALUE) { 
                        //check if there is still space in intArray for new elements
                        if (intArray[pos] == Integer.MIN_VALUE) { 
                            //check if the current pos is empty
                            System.out.println("Adding value to IntArray");
                            intArray[pos] = scanner.nextInt();
                            //assign nextInt to current pos
                            System.out.println("Value at index " + pos + " is now " + intArray[pos]);
                            done = true; 
                            success = true; 
                            break;
                        }

                    }else{

                        //if all spots in the intArray are full, reject new additions
                        String reject = scanner.next();
                        System.out.println("IntArray is now full");
                        done = true;
                        break; 
                    }

                    if(intArray.length-1 == pos){ 
                        //check end of intArray while looping intArray
                        done = true; 
                        break; 
                    }

                    pos++;
                }

            }else{ 

                //if the next value is not an integer
                if(skipErrors){ 

                    //check to skip errors
                    String reject = scanner.next(); 
                    //reject non-integer 
                }else{ 

                    //reject non-integer, reset all values MIN_VALUE
                    String reject = scanner.next();
                    System.out.println("Could not add value. Resetting  to Integer.MIN_VALUE");
                    Arrays.fill(this.intArray, Integer.MIN_VALUE);
                    break;
                }

            }

        }
        return success; 
        //return  
    }

    public static void main(String[] args) {

        String str;
        Scanner scanner = new Scanner(System.in);
        StringToIntArray str2Arr = new StringToIntArray();
        System.out.println("Please enter a string ");
        
        str = scanner.nextLine();
        str2Arr.scanStringToIntArray(str, true);
        System.out.println(Arrays.toString(str2Arr.intArray));
    }

}
