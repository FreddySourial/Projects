import java.util.Scanner;
/* CST8110 - Introduction to Computer Programming
 * Section: 472
 * Semester: 20F
 * Professor: Wail Mardini
 * Student ID: 041013272
 * Student Email: sour0025@algonquinlive.com
 * Assignment 3
 */
public class Package
{

    private double height; //assigning length width and hight as private

    private double width;

    private double length;

    private Scanner input=new Scanner(System.in); // calling scanner utility

    public Package()
    {
        //assigning all the deafualt values to 1.0 as stated in the assignment instructions
        height=1.0; 

        width=1.0;

        length=1.0;

    }

    public Package(double length, double width, double height) {
        super();
        this.height = height;

        this.width = width;

        this.length = length;
        //parameterizing constructor
    }

    public Package(Package p)
    {
        height=p.height;

        width=p.width;

        length=p.length;
        //copying constructor 
    }

    public void inputLength()
    {
        System.out.print("Please Enter length : "); //asking for a value for length
        length=input.nextDouble();
    }
    //function to enter width
    public void inputWidth()
    {
        System.out.print("Please Enter Width : "); //asking for a value for width
        width=input.nextDouble();
    }

    public void inputHeight()
    {
        System.out.print("Please Enter Height : "); //asking for a value for height
        height=input.nextDouble();
    }

    public void displayDimensions()
    {
        System.out.println ("The Box Dimensions are: "+length+ "X" +width+ "X" +height);
    }

    public double calcVolume()
    {
        return height*length*width; //returning the vloume of the box
    }  
}
