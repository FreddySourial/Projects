import java.util.Scanner;

/* CST8110 - Introduction to Computer Programming
 * Section: 472
 * Semester: 20F
 * Professor: Wail Mardini
 * Student ID: 041013272
 * Student Email: sour0025@algonquinlive.com
 * Student Name: Freddy Sourial
 * Practical assesment #1
 */


public class TestMax {
	int minNum= 1;
	int maxNum= 10;
    
		public int inputNum() {
	
		System.out.println("");
	
	Scanner inputNum = new Scanner(System.in);  // Create a Scanner object
    System.out.println("Please enter an integer between between 1 and 10");

    String userName = myObj.nextLine();  // Read user input
    System.out.println("Username is: " + userName);  // Output user input

      
	  
	  
	  
	  
       // write a println statement to print any welcome message. example println("");
		System.out.println("Welcome to assignment#1 for intro to programming!");
       // write a println statement to print name above. example println(name);
		System.out.println (name);
       // write a println statement to print id1 and then another println for id2
		System.out.println(id1);
		System.out.println (id2);
       // write a println statement without any argument 
	  System.out.println ("no arguments");
       // write a print statement to print id1 and then another print for id2
	   System.out.println (id1);
		System.out.println (id2);
        
       
	} // end method main

} // end class Assignment1

		public void displayNum(int userNum) {
		}
	

		public static void main(String[] args){
		}
		
}
