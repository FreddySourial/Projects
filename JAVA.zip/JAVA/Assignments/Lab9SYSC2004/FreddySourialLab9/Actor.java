import java.util.List;
/**
 * Write a description of interface Actor here.
 *
 * @author (Freddy Sourial)
 * @version (March 22nd 2020)
 */
public interface Actor
{
    void act(List<Actor> newActors);
    abstract public boolean isActive();
}
