
/**
 * Write a description of class as here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class as
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class as
     */
    public as()
    {
        public class FieldVLocVar {
     int i= 40;
     int j;
     
     public  FieldVLocVar ( )  {
     setValue (i++);
     }
    
     void setValue(int inputValue) {
      int i=20;
      j = i + 1;
     System.out.println(“ j =  ” + j);
    }
} // end class FieldVLocVar

    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
