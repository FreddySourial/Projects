
/**
 * Write a description of class a here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class a
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class a
     */
    public a()
    {
        
        for (int i = 1;  i <5; i++){
            int product = 1;
      product = product* i;
      System.out.println( "product is"  + product);
        x = 0;
        
    }
        int i = 0;

}

    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
