
/**
 * Write a description of class FieldVLocVar here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FieldVLocVar
{
         int i= 40;
     int j;
     
     public  FieldVLocVar ( )  {
     setValue (i++);
     }
    
     void setValue(int inputValue) {
      int i=20;
      j = i + 1;
     System.out.println(" j =  " + j);
    }
} // end class FieldVLocVar

