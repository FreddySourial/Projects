 
- find out about what Ordinal.java is for
- Review all written code to fully understand how to move forward
- Call Dan back to complete checkVictory()