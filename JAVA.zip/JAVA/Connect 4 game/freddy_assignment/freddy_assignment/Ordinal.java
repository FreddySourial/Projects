public class Ordinal {
	/*
     * Returns the ordinal value of the specified integer value.
     * 
     * @param integer A cardinal integer value.
     * @return The ordinal value of the cardinal integer value.
     */
	 
    public static String getOrdinal(int integer) {
        // TODO: implement getOrdinal
        // hint: use modulus division and a switch statement
	}
}